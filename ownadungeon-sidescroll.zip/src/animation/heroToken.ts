// Moves the hero token left-to-right across the sidescrolling raid stage
// and keeps its visual reaction state (idle/panic/rage/flee/dead) in sync.
// Replaces the isometric-tile version — see
// /backup/isometric/src/animation/heroToken.ts for the previous version.
//
// Public API is unchanged on purpose so combat/raid.ts and
// ui/battleReaction.ts don't need to change at all.

import { getHeroIcon } from '../ui/heroIcon';
import { ENTRANCE_X, ENCOUNTER_X, EXIT_X, FLOOR_Y } from './laneLayout';
import { beatMs } from './beatTiming';
import type { Hero } from '../types';

function getToken(): HTMLElement | null {
  return document.getElementById('hero-token');
}

function setTokenX(xPct: number, ms?: number): void {
  var token = getToken();
  if (!token) return;
  if (typeof ms === 'number') {
    token.style.transitionDuration = ms + 'ms, ' + ms + 'ms, 0.25s';
  }
  token.style.left = xPct + '%';
  token.style.top = FLOOR_Y + '%';
}

export function showHeroToken(hero: Hero): void {
  var token = getToken();
  var runway = document.getElementById('dungeon-runway');
  if (!token || !runway) return;

  var face = token.querySelector('.hero-token-face');
  if (face) face.textContent = getHeroIcon(hero);

  token.classList.add('is-visible');
  token.classList.remove('is-flee', 'is-dead', 'is-entering');
  runway.classList.add('is-raiding');
}

export function hideHeroToken(): void {
  var token = getToken();
  var runway = document.getElementById('dungeon-runway');
  if (!token || !runway) return;
  token.classList.remove('is-visible', 'is-panic', 'is-rage', 'is-flee', 'is-dead', 'is-entering');
  token.style.left = '';
  token.style.top = '';
  runway.classList.remove('is-raiding', 'is-room-mode');
  var app = document.querySelector('.app');
  if (app) app.classList.remove('battle-active');
  document.body.classList.remove('battle-active');
}

export function syncHeroTokenVisual(hero: Hero | null): void {
  var token = getToken();
  if (!token || !hero) return;
  token.classList.remove('is-panic', 'is-rage', 'is-flee', 'is-dead');
  if (hero.visualState === 'panic') token.classList.add('is-panic');
  if (hero.visualState === 'rage') token.classList.add('is-rage');
  if (hero.visualState === 'flee') token.classList.add('is-flee');
  if (hero.visualState === 'dead') token.classList.add('is-dead');
  var face = token.querySelector('.hero-token-face');
  if (face) face.textContent = getHeroIcon(hero);
}

/** Instant reset to the entrance (left edge) — called at the start of every room. */
export function placeHeroAtEntrance(): void {
  var token = getToken();
  if (!token) return;
  token.classList.add('no-motion');
  setTokenX(ENTRANCE_X, 0);
  requestAnimationFrame(function () {
    token.classList.remove('no-motion');
  });
}

/** Entrance -> center, where the fight/trap happens. */
export function walkHeroToEncounter(): void {
  setTokenX(ENCOUNTER_X, beatMs('arriveRoom'));
}

/** Center -> exit (right edge), toward the next room. */
export function walkHeroToExit(): void {
  setTokenX(EXIT_X, beatMs('betweenRooms'));
}

export function resetStageView(): void {
  hideHeroToken();
  placeHeroAtEntrance();
  document.querySelectorAll('.dungeon-slot').forEach(function (s) {
    s.classList.remove('raid-active', 'raid-cleared', 'slot-triggered', 'slot-kill');
  });
}
